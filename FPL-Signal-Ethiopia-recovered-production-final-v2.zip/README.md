# FPL Signal Ethiopia 🇪🇹

**DATA • STRATEGY • SIGNAL**

FPL Signal Ethiopia is a Telegram-first Fantasy Premier League product with a Telegram Bot, Telegram Mini App, API server, PostgreSQL database, and shared workspace libraries.

## Repository structure

- `artifacts/api-server` — Express API and Telegram bot
- `artifacts/fpl-signal-mini-app` — Telegram Mini App (React/Vite)
- `lib/db` — PostgreSQL/Drizzle database layer
- `lib/api-zod` — API schemas
- `lib/api-client-react` — generated React API client
- `lib/api-spec` — API specification
- `scripts` — workspace scripts

## Required environment

API server:

- `DATABASE_URL`
- `TELEGRAM_BOT_TOKEN`
- `PORT`
- `MINI_APP_URL`
- optional `MINI_APP_ORIGIN`
- optional `LOG_LEVEL`

Mini App build/runtime:

- `PORT`
- `BASE_PATH`
- optional `VITE_API_BASE_URL` when the API is hosted on a different origin

## Install and validate

Use pnpm (Node.js 20+ recommended):

```bash
pnpm install --frozen-lockfile
pnpm run typecheck
pnpm test
pnpm run build
```

The scoring test suite is exposed as the root `pnpm test` command.

## Production notes

- Telegram long polling uses a PostgreSQL advisory lock so only one running instance owns polling at a time.
- Weekly score refresh protects the latest saved scores when FPL live data is temporarily unavailable.
- After a gameweek rolls over, the immediately previous gameweek is refreshed as well so its final points can settle.
- `/api/healthz` is a liveness endpoint; `/api/readyz` checks database readiness.
- The Mini App can use `VITE_API_BASE_URL` for a separately hosted API.

## Recovery

The original source was recovered from the Base64 ZIP recovery payload. The recovery workflow in `.github/workflows/recover-source.yml` verifies the archive before replacing the source tree and committing it to `main`.

## GW የክፍያ ውድድር መዋቅር

ፕሮጀክቱ አሁን ለየGameweek የሚከፈል ውድድር የDB/API/Mini App መሠረት አለው። የክፍያ ሁኔታ በserver ይረጋገጣል፤ frontend ብቻ ክፍያን እንደተሳካ ማድረግ አይችልም። Chapa callback እና webhook ከserver-side transaction verification ጋር ይጠቀማሉ።

**አስፈላጊ:** `GW_COMPETITION_PAID_ENABLED=false` ነው የተቀመጠው። ከተሳታፊዎች ገንዘብ መቀበል እና ሽልማት መክፈል ከመጀመሩ በፊት የሚመለከተው የህግ/ፈቃድ ምርመራ መጠናቀቅ አለበት።

## Production launch checklist

Before enabling paid GW competition in production:

1. Run `pnpm install --frozen-lockfile`, `pnpm run typecheck`, `pnpm test`, and `pnpm run build` in a networked CI/deployment environment.
2. Apply database migrations with `pnpm --filter @workspace/db migrate`.
3. Configure Telegram, Mini App, PostgreSQL, and Chapa secrets only in the deployment environment; never commit secrets.
4. Test Chapa in its test/sandbox environment, including callback, webhook retry, duplicate webhook, pending payment, and failed payment cases.
5. Keep `GW_COMPETITION_PAID_ENABLED=false` until the required Ethiopian legal/licensing review is complete.
6. After legal clearance, enable paid competition only after verifying the entry fee, webhook secret, callback URL, return URL, and admin token.
7. Prize payouts are recorded manually with a payout reference; the system does not silently transfer prize money.
