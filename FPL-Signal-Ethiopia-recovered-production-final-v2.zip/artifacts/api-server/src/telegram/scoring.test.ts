import assert from "node:assert/strict";
import { calculateWeeklyScore } from "./scoring";
import { validateCaptainPair } from "./squad-rules";
import type { FplLivePlayerStats, FplPlayer } from "./fpl";

const players: FplPlayer[] = [
  { id: 1, name: "Goalkeeper 1", club: "A", clubId: 1, position: "goalkeeper", price: 5 },
  { id: 2, name: "Goalkeeper 2", club: "B", clubId: 2, position: "goalkeeper", price: 5 },
  ...Array.from({ length: 5 }, (_, index) => ({
    id: 10 + index,
    name: `Defender ${index + 1}`,
    club: String.fromCharCode(67 + index),
    clubId: 3 + index,
    position: "defender" as const,
    price: 5,
  })),
  ...Array.from({ length: 5 }, (_, index) => ({
    id: 20 + index,
    name: `Midfielder ${index + 1}`,
    club: String.fromCharCode(72 + index),
    clubId: 8 + index,
    position: "midfielder" as const,
    price: 5,
  })),
  ...Array.from({ length: 3 }, (_, index) => ({
    id: 30 + index,
    name: `Forward ${index + 1}`,
    club: String.fromCharCode(77 + index),
    clubId: 13 + index,
    position: "forward" as const,
    price: 5,
  })),
];

const startingPlayerIds = [1, 10, 11, 12, 13, 20, 21, 22, 23, 30, 31];
const defaultBenchPlayerIds = [32, 2, 14, 24];

function stats(points: Record<number, number>, minutes = 90): Map<number, FplLivePlayerStats> {
  return new Map(players.map((player) => [
    player.id,
    { minutes, totalPoints: points[player.id] ?? 1 },
  ]));
}

function team(overrides: Partial<{
  startingPlayerIds: number[];
  benchPlayerIds: number[];
  captainPlayerId: number;
  viceCaptainPlayerId: number | null;
}> = {}) {
  return {
    selectedPlayerIds: [...startingPlayerIds, ...defaultBenchPlayerIds],
    startingPlayerIds: overrides.startingPlayerIds ?? startingPlayerIds,
    benchPlayerIds: overrides.benchPlayerIds ?? defaultBenchPlayerIds,
    captainPlayerId: overrides.captainPlayerId ?? 30,
    viceCaptainPlayerId: overrides.viceCaptainPlayerId ?? 20,
  };
}

{
  const result = calculateWeeklyScore(team(), players, stats({ 30: 7 }));
  assert.equal(result.totalPoints, 24);
  assert.deepEqual(result.scoredPlayerIds, startingPlayerIds);
}

{
  const live = stats({ 20: 5, 30: 0, 32: 4 });
  live.set(30, { minutes: 0, totalPoints: 0 });
  const result = calculateWeeklyScore(team({ benchPlayerIds: [32, 2, 14, 24] }), players, live);
  assert.equal(result.totalPoints, 23);
  assert.deepEqual(result.substitutions, [{ replacedPlayerId: 30, substitutePlayerId: 32 }]);
}

{
  const live = stats({ 20: 0, 30: 0, 32: 4, 24: 3 });
  live.set(20, { minutes: 0, totalPoints: 0 });
  live.set(30, { minutes: 0, totalPoints: 0 });
  const result = calculateWeeklyScore(
    team({ benchPlayerIds: [32, 24, 2, 14] }),
    players,
    live,
  );
  assert.equal(result.totalPoints, 16);
  assert.equal(result.substitutions.length, 2);
  assert.equal(result.totalPoints, 16);
}

{
  const live = stats({ 30: 7 });
  live.set(30, { minutes: 1, totalPoints: 0 });
  const result = calculateWeeklyScore(team(), players, live);
  assert.equal(result.substitutions.length, 0);
  assert.equal(result.scoredPlayerIds.includes(30), true);
  assert.equal(result.totalPoints, 10);
}

{
  assert.equal(validateCaptainPair(startingPlayerIds.map((id) => players.find((player) => player.id === id)!), 30, 30).ok, false);
  assert.equal(validateCaptainPair(startingPlayerIds.map((id) => players.find((player) => player.id === id)!), 32, 20).ok, false);
  assert.throws(() => calculateWeeklyScore(team({ captainPlayerId: 32 }), players, stats({})));
}

console.log("scoring tests passed");